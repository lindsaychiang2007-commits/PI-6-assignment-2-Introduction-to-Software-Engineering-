package org.example;

import java.sql.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String url = "jdbc:sqlite:booktracker.db";
        Scanner scanner = new Scanner(System.in);

        try (Connection conn = DriverManager.getConnection(url)) {
            Statement stmt = conn.createStatement();


            stmt.execute("CREATE TABLE IF NOT EXISTS User (userid TEXT PRIMARY KEY, age INTEGER)");

            while (true) {
                System.out.println("\nMENU: 1-AddUser, 2-Habits, 3-UpdateBook, 4-Delete, 5-TotalPages, 6-Mean age 0-Exit");
                System.out.print("Enter choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                if (choice == 0) break;

                switch (choice) {
                    case 1:
                        System.out.print("User ID: ");
                        String uid = scanner.nextLine();

                        System.out.print("Age: ");
                        int age = scanner.nextInt();

                        String myCommand = "INSERT OR IGNORE INTO User VALUES ('" + uid + "', " + age + ")";
                        stmt.executeUpdate(myCommand);
                        System.out.println("Saved!");
                        break;

                    case 2:
                        System.out.print("Search User ID: ");
                        String searchid = scanner.nextLine();

                        ResultSet middleperson = stmt.executeQuery("SELECT * FROM \"reading_habits_datasets\" WHERE userid = '" + searchid + "'");
                        while (middleperson.next())
                            System.out.println("Book: " + middleperson.getString("book") + " | Pages: " + middleperson.getInt("pagesread"));
                        break;

                    case 3:
                        System.out.print("Old Title: ");
                        String oldT = scanner.nextLine();

                        System.out.print("New Title: ");
                        String newT = scanner.nextLine();

                        int rowsUpdated = stmt.executeUpdate("UPDATE \"reading_habits_datasets\" SET book = '" + newT + "' WHERE book = '" + oldT + "'");
                        System.out.println(rowsUpdated + " titles updated.");
                        break;

                    case 4:
                        System.out.print("Habit ID to delete: ");
                        int hid = scanner.nextInt();

                        stmt.executeUpdate("DELETE FROM \"reading_habits_datasets\" WHERE habitid = " + hid);
                        System.out.println("Record removed.");
                        break;

                    case 5:
                        ResultSet middleperson2 = stmt.executeQuery("SELECT SUM(pagesread) FROM \"reading_habits_datasets\"");
                        if (middleperson2.next()) System.out.println("Total Pages Read: " + middleperson2.getInt(1));
                        break;

                    case 6:
                        ResultSet ageResult = stmt.executeQuery("SELECT AVG(age) FROM User");
                        if (ageResult.next()) {
                            System.out.println("The average user age is: " + ageResult.getDouble(1));
                        }
                        break;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}